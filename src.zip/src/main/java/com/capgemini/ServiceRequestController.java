package com.capgemini;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entities.ServiceCatalog;
import com.capgemini.entities.ServiceRequest;
import com.capgemini.entities.Vehicle;
import com.capgemini.repository.ServiceCatalogRepository;
import com.capgemini.repository.ServiceRequestRepository;
import com.capgemini.repository.VehicleRepository;

@RestController
@RequestMapping("/api/servicerequest/")
public class ServiceRequestController {

	@Autowired
	private ServiceRequestRepository serreqrepository;
	
	@Autowired
	private VehicleRepository vehiclerepository;
	
	@Autowired
	private ServiceCatalogRepository sercatrepo;
	
	//creating the service request
	@PostMapping("/")
	public String create(@RequestBody ServiceRequest servicerequest) {
		if(servicerequest.getVehicle()!=null) {
			Vehicle vehi=vehiclerepository.findById(servicerequest.getVehicle().getVehicle_reg_no()).get();
			servicerequest.setVehicle(vehi);
		}
		if(servicerequest.getServiceCatalog()!=null) {
			ServiceCatalog ser_cat=sercatrepo.findById(servicerequest.getServiceCatalog().getService_catalog_id()).get();
			servicerequest.setServiceCatalog(ser_cat);
		}
		
		serreqrepository.save(servicerequest);
		return "Request Added!!!";
	}
	
	//finding all the details of all service request
	@GetMapping("/")
	public List<ServiceRequest> getRequest(){
		return serreqrepository.findAll();
	}
	
	//finding request details by id
	@GetMapping("/{service_req_id}")
	public ServiceRequest getRequestById(@PathVariable Integer service_req_id) {
		return serreqrepository.findById(service_req_id).get();
	}
}
