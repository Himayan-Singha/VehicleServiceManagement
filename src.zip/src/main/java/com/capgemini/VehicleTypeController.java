package com.capgemini;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entities.VehicleType;
import com.capgemini.repository.VehicleTypeRepository;

@RestController
@RequestMapping("/api/vehicletype/")
public class VehicleTypeController {
	
	@Autowired
	private VehicleTypeRepository vehicletyperepository;
	
	@PostMapping("/")
	public String create(@RequestBody VehicleType vehicletype) {
		vehicletyperepository.save(vehicletype);
		return "Vehicle Type Added";
	}

}
