package com.capgemini;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entities.ServiceCatalog;
import com.capgemini.entities.ServiceType;
import com.capgemini.repository.ServiceCatalogRepository;
import com.capgemini.repository.ServiceTypeRepository;

@RestController
@RequestMapping("/api/servicecatalog/")
public class ServiceCatalogController {
	
	@Autowired
	private ServiceCatalogRepository sercatrepository;
	@Autowired
	private ServiceTypeRepository sertyperepository;

	@PostMapping("/")
	public String create(@RequestBody ServiceCatalog servicecatalog) {
		
		if(servicecatalog.getServicetype()!=null) {
			ServiceType sertype=sertyperepository.findById(servicecatalog.getServicetype().getService_id()).get();
			servicecatalog.setServicetype(sertype);
		}
		sercatrepository.save(servicecatalog);
		return "Service Catalog created!!!";
	}
}
